import { LoginPage } from "./pages/login.cy"
import { AddProducts } from "./pages/addproducts.cy"
import { PlaceOrders } from "./pages/placehorder.cy"

const loginPage = new LoginPage()
const addProducts = new AddProducts()
const placeorder = new PlaceOrders()

beforeEach(function(){
    cy.visit("https://www.demoblaze.com/")
    cy.wait(2000)
})

describe('All Tests' , function()
    {               
        beforeEach(function(){
            cy.get('#login2').click()
            cy.wait(2000)                
        })

        it('Add Products with form not empty', function()
        {  
            loginPage.enterUsername('1234')
            loginPage.enterPassword('1234')
            loginPage.clickLogin()            
            cy.wait(5000)
            addProducts.AddProduct1()
            cy.wait(3000)
            addProducts.AddedPr()
            cy.get('.active > .nav-link').click()
            addProducts.AddProduct2()
            cy.wait(3000)
            addProducts.AddedPr()
            cy.get(':nth-child(4) > .nav-link').click()
            cy.wait(4000)
            placeorder.Placeord()
            placeorder.Form()
            placeorder.NameCustomer('AAAA')
            placeorder.CountryCustomer('AAAA')
            placeorder.CityCustomer('AAAA')
            placeorder.CardCustomer('12356988998')
            placeorder.MonthCardCustomer('12')
            placeorder.YearCardCustomer('2023')
            placeorder.Purchase()
            placeorder.ConfPurchase()
        }) 
        
        it('Add Products with form empty', function()
        {  
            loginPage.enterUsername('1234')
            loginPage.enterPassword('1234')
            loginPage.clickLogin()            
            cy.wait(5000)
            addProducts.AddProduct1()
            cy.wait(3000)
            addProducts.AddedPr()
            cy.get('.active > .nav-link').click()
            addProducts.AddProduct2()
            cy.wait(3000)
            addProducts.AddedPr()
            cy.get(':nth-child(4) > .nav-link').click()
            cy.wait(4000)
            placeorder.Placeord()
            placeorder.Form()
            placeorder.NameCustomer('')
            placeorder.CountryCustomer('')
            placeorder.CityCustomer('')
            placeorder.CardCustomer('')
            placeorder.MonthCardCustomer('')
            placeorder.YearCardCustomer('')
            placeorder.Purchase()
            placeorder.ConfPurchase()
        }) 

        
       
    })