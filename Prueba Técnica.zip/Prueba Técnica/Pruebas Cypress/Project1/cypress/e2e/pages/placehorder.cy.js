export class PlaceOrders{  

    button= '.col-lg-1 > .btn'
    formul= '#orderModalLabel'
    name_textbox= '#name'
    country_textbox= '#country'
    city_textbox= '#city'
    card_textbox= '#card'
    month_textbox= '#month'
    year_textbox= '#year'
    purchase_button= '#orderModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary'
    confirmpurch='.confirm'
    
    Placeord(){
         cy.get(this.button)
         .should('contain','Place Order')
         .and('be.visible')      
         .click()
         cy.wait(5000) 
     }

     Form(){
        cy.get(this.formul)
        .should('contain','Place order')
        .and('be.visible')  
    }

    NameCustomer(names){
        cy.get(this.name_textbox).type(names)
        cy.wait(2000)
    }

    CountryCustomer(country){
        cy.get(this.country_textbox).type(country)
        cy.wait(2000)
    }

    CityCustomer(city){
        cy.get(this.city_textbox).type(city)
        cy.wait(2000)
    }

    CardCustomer(card){
        cy.get(this.card_textbox).type(card)
        cy.wait(2000)
    }

    MonthCardCustomer(month){
        cy.get(this.month_textbox).type(month)
        cy.wait(2000)
    }
     
    YearCardCustomer(year){
        cy.get(this.year_textbox).type(year)
        cy.wait(2000)
    }

    Purchase(){
        cy.get(this.purchase_button).click()
        cy.wait(2000)
    }

    ConfPurchase(){
        cy.get(this.confirmpurch).click()
        cy.wait(2000)
    }

    

 }
 