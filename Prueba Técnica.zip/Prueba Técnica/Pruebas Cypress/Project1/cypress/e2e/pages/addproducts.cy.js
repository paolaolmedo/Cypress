export class AddProducts{  

   p1 = ':nth-child(1) > .card > .card-block > .card-title > .hrefch'
   p2 = ':nth-child(5) > .card > .card-block > .card-title > .hrefch'
   add= '.col-sm-12 > .btn'
    
    AddProduct1(){
        cy.get(this.p1).click()
        cy.wait(3000) 
    }

    AddProduct2(){
        cy.get(this.p2).click()
        cy.wait(3000)     
    } 

    AddedPr(){
        cy.get(this.add)
        .should('contain','Add to cart')
        .and('be.visible')      
        .click()
        cy.wait(5000) 
    }   
}
