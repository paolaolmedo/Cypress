export class LoginPage{  

    username_textbox = '#loginusername'
    password_textbox = '#loginpassword'
    login_button = '#logInModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary'

    enterUsername(username){
        cy.get(this.username_textbox).type(username)
        cy.wait(5000)       
    }

    enterPassword(password){
        cy.get(this.password_textbox).type(password)
        cy.wait(5000)
    }

    clickLogin(){
        cy.get(this.login_button).click()
        cy.wait(5000) 
    }    
}