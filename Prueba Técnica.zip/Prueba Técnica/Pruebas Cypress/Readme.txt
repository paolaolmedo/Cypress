1. Abrir Visual Studio Code
2. Abrir la carpeta Project1
3. Ir al archivo pomdemo.cy.js
4. En el menú ir a Terminal
5. Escribir la siguiente linea: npx cypress open
6. Seleccionar E2E Testing
7. Seleccionar cualquier navegador, ejm: Chrome
8. Click in Start E2E Testing in Chrome
9. Seleccionar el archivo pomdemo.cy.js
10. Verificar que ejecute los dos casos de prueba
    El caso de prueba llamado Add Products with form
     not empty debe ejecutarse como pasado
    El caso de prueba llamado Add Products with form
     empty debe ejecutarse como fallido, ya que
     no permite agregar un formulario sin datos.	