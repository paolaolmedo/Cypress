1. Abrir Postman
2. Clic en File / Import
3. Seleccionar la carpeta Pruebas Postman
4. Seleccionar el archivo llamado API inicio.postman_collection
5. Ejecutar cada uno de los request que se encuentran en la colección
6. Abrir el archivo en Word llamado Pruebas realizadas API, ya que
   explica la ejecución de las pruebas, que fueron fallidas.